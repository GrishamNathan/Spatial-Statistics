This file requires third party Software to be viewed. It is comprised of geographical and atribute information.

Geographic data contained in this dataset best viewed with the Toronto Centreline file as a background. 

Column name  (Description)
======================================
GEO_ID = GEO_ID  (UNIQUE GEOGRAPHIC SEUQENTIAL NUMBER)
NAME = NAME
SCL_LVL = SCHOOL_LEVEL  (SCHOOL_LEVEL
)
SCL_TP = SCHOOL_TYPE  (SCHOOL_TYPE
)
BRD_NAME = BOARD_NAME  (BOARD_NAME
)
SCL_TP_DSC = SCHOOL_TYPE_DESC  (SCHOOL_TYPE_DESC
)
ADD_PT_ID = ADDRESS_POINT_ID  (ADDRESS_POINT_ID
)
ADD_NUM = ADDRESS_NUMBER  (ADDRESS_NUMBER)
LN_NAM_FUL = LINEAR_NAME_FULL  (LINEAR_NAME_FULL
)
ADD_FULL = ADDRESS_FULL  (ADDRESS_FULL)
POSTAL_CD = POSTAL_CODE  (POSTAL_CODE
)
MUN = MUNICIPALITY  (MUNICIPALITY
)
CITY = CITY
GEN_USE_CD = GENERAL_USE_CODE  (GENERAL_USE_CODE
)
CNTL_ID = CENTRELINE_ID  (CENTRELINE_ID
)
LO_NUM = LO_NUM
LO_NUM_SUF = LO_NUM_SUF
HI_NUM = HI_NUM
HI_NUM_SUF = HI_NUM_SUF
LN_NAM_ID = LINEAR_NAME_ID  (LINEAR_NAME_ID
)
X = X  (Easting, in MTM NAD 27(3 degree) Projection
)
Y = Y  (Northing, in MTM NAD 27(3 degree) Projection
)
LATITUDE = LATITUDE  (Latitude in WGS84 Coordinate System
)
LONGITUDE = LONGITUDE  (Longitude in WGS84 Coordinate System
)
OBJECTID = OBJECTID  (Unique system identifier)
